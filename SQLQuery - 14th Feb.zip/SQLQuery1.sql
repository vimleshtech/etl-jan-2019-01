/*
Subquery : query inside query 
Union	 : 
Function :
*/


use hrms

select * from employee
select * from c_employee

--return 2nd highest salary 
select max(salary) from c_employee


select top 1 * From c_employee 
where salary < (select max(salary) from c_employee)
order by salary desc 


select top 1 * from (select top 2 * from c_employee order by salary desc ) t
order by salary asc 


--return 3r lowest
select top 1 * from (select top 3 * from c_employee order by salary asc ) t
order by salary desc


/*
product 
pid  pname  pprice  sprice 
1     dove   40     45
2     dell   34000   45000


transactions
tid pid qty tran_type tran_date
1   2   100   p			2020-01-10
2   2   20    p			2020-01-11
3   1   300   p			2020-01-12
4   2   30    s			2020-02-10
5   1   40    s			2020-01-10
6   1   10    s			2020-02-10	

expected output:
pid  pname  total_qty_purchase  total_qty_sale   qty_in_stock 
1    dove   	300                  50             250
2    dell   	120                  30             90
*/





