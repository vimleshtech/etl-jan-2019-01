-- create database 
create database etl_learn

--switch databse 
use etl_learn   

--create table 
create table employee(
eid int identity(100,1) primary key,
fname  varchar(100) not null,
lname varchar(100) null,
email varchar(30) unique,
gender char(1) ,
dob  datetime,
country varchar(100),
salary int
)

--show data 
select * from employee -- * show all columns


--projection : show selected columns
select eid,fname from employee 

--alias 
select eid as employee_code,fname from employee 

-- insert data in table
insert into employee(fname,email,dob)
values('MOnika','mona@gmail.com','2010-11-02')
 --- yyyy-mm-dd


--selection : select row: show selected column
select * from employee where eid > 112


-- update value in existing row
update employee 
set lname ='Sharma'
where eid =110


-- delete row 
delete from employee --delete all rows

--delete selected row 
delete from employee where eid =100

-- order by : show in asc or desc order 
select * from employee order by eid desc 

select * from employee order by fname  desc 

-- group by : summarize the data 
select fname, count(fname) 
from employee group by fname  

------------------practice

create database new_class

use new_class

create table sales.student1(
sid int identity(100,1) primary key,
fname  varchar(100) not null,
lname varchar(100) null,
email varchar(30) unique,
gender char(1) ,
dob  datetime,
country varchar(100),
salary int
)

select * from student

insert into student(fname,email,dob)
values('javed','wani.javed@gmail.com','2010-11-02')





